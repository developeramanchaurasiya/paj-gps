
-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
CREATE TABLE IF NOT EXISTS `devices` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_unique_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `devices_device_unique_id_unique` (`device_unique_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `name`, `model`, `device_unique_id`, `created_at`, `updated_at`) VALUES
(1, 'est', 'consequuntur', '1a4df7f7-0083-3b3b-9415-35ae6ee523d9', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(2, 'sapiente', 'deleniti', '53bb505c-ca40-346e-8374-69c71005da76', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(3, 'quia', 'at', 'c494f5e1-16d8-3eec-95a6-de2cb289c9ef', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(4, 'ullam', 'et', 'd7c0fbb1-b07f-3423-827a-d97902d03ac1', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(5, 'dolores', 'in', 'c03c73a2-5578-3f28-abea-0a262fdba88a', '2024-11-21 15:23:58', '2024-11-21 15:23:58');

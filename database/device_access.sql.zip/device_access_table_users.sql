
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Aman Chaurasiya', 'aman@gmail.com', '$2y$12$T3dFUS28Qn/XuYW5so1yW.ygx68d1oeDDxmq7Iuj00zDLDRB0v5vq', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(2, 'Dr. Meredith Boyle', 'streich.carlo@example.net', '$2y$12$ds7vLqjk0F1ujIP3gN6ngO7BnldrVK9zvZraDBQ6OCoBykeQP4ZW.', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(3, 'Marjorie Gusikowski III', 'cordelia.wiza@example.com', '$2y$12$6R6GP3ag5.ai3KFUjTimJOv//DB28/qCC7RDATqdfz8X4kth1yITS', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(4, 'Prof. Marc Kreiger', 'nkuhic@example.org', '$2y$12$ToFEZ9e3LdnOICucpWAxkeFYJLt8pC3wOCFATGIoVdE099E9y0QRW', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(5, 'Pietro Mosciski', 'hemmerich@example.com', '$2y$12$K.70j07vZPm8ySoIz6oTeeyN5/YOAFNUy7lHtJfq8zbJ.wN69cTM2', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(6, 'Imelda Terry', 'keyshawn35@example.com', '$2y$12$p2TlXXc9kLz40oys9eOtM.LcSm19XZMPlhxhowJToPALHKIBvsPnO', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(7, 'Dr. Kelsie Bernier', 'nolan.lynn@example.org', '$2y$12$TmT7qCJj2UevLK3F10O6O.g1G990ReuTq0WL446kUdECI/omFDIGa', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(8, 'Dr. Aniya Feest DVM', 'damore.louisa@example.org', '$2y$12$wWHBcQYyuNPn22trZI6COOnHbL2O47j7Qc9rpFPZtsHJig.Oz/rvW', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(9, 'Sherwood Mayer', 'xturner@example.org', '$2y$12$BYjGdaY/Z/bILmX2HAheVuafdBYcjfRr0dZqyuNUXk9vVJXtr68Ta', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(10, 'Dr. Aurelie Smitham V', 'bkerluke@example.net', '$2y$12$D.4uMXaWI/wBhnE7WFJAI.LUHbaiiBdPuhOdfIYu35au/1YHYcQ2W', '2024-11-21 15:23:07', '2024-11-21 15:23:07'),
(11, 'Nicholaus Walter', 'ettie91@example.com', '$2y$12$hZ0pfvWvAk2mbzsJuA8J0eYA8g6XMtI0mGL/ItViPB0pTOsTjUkVq', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(12, 'Albertha Kohler DVM', 'schiller.oceane@example.net', '$2y$12$sHNq16FdzJsU.MJ92ksFKOoeDJZYgA2JlL6WSFSl5qkwSlFKCuELi', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(13, 'Isaias Sipes', 'eliza.emmerich@example.net', '$2y$12$XbNKc8nwC9xhQLQBz4Z8he6Sj0uHBx/znk8jZ4KXcYqCJuY.9AqBW', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(14, 'Lance Towne', 'conn.abdullah@example.org', '$2y$12$WT1Qfx6TpFPb3G0HPSR0gO0IE5Y9nA1gPbrWBqHjTi4AFKJpZExpy', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(15, 'Kacey Stehr III', 'sromaguera@example.org', '$2y$12$fCMzcQqTLSitNJdmaoCn/uIvZc2fUEzPAzrwoKaYuzLis6WzlPkzG', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(16, 'Mr. Jefferey Wehner', 'hills.deion@example.net', '$2y$12$XSMBFLYbewbxJIoKuFiPCOXvUb1XbohemyYwPev7Cq2KanOSoCxtK', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(17, 'Prof. Jaylen Koss', 'lambert.beer@example.net', '$2y$12$pUagfUDWfhN99aYuD2U77ebs.QoUHu0DP3fgwnkum5iqDE5JJPucq', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(18, 'Annabel Jerde', 'kacey05@example.org', '$2y$12$vjT4kbJYU4/dybTIlBkJzuqkohDV..qN5oPNDOATxUQB3XzRiTZAK', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(19, 'Ms. Ruthe Lakin III', 'brain39@example.net', '$2y$12$.pp/D9CdInp.4IxMZ/vfz.TaJGgr0SQEtyS4uVz1QlNMVCXwlw.BO', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(20, 'Rick Stark DDS', 'raoul64@example.net', '$2y$12$MOtVW7OHSUt3I2qfLg.75OneCN.u9Mxs.A3FQa86notwFWlVK2M6.', '2024-11-21 15:23:58', '2024-11-21 15:23:58'),
(21, 'Jane Doe', 'jane.doe@example.com', '$2y$12$zh9sRO8Hvp5MkvdTsp7EQ.nXFH0E0Dkw1sGV7.J2RsQIE61kwikCi', '2024-11-21 15:30:34', '2024-11-21 15:30:34'),
(22, 'Jane Doe12', 'jane.do12e@example.com', '$2y$12$T3dFUS28Qn/XuYW5so1yW.ygx68d1oeDDxmq7Iuj00zDLDRB0v5vq', '2024-11-21 16:03:34', '2024-11-21 16:03:34');

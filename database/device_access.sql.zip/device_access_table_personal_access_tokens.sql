
-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(4, 'App\\Models\\User', 22, 'auth_token', '9f615c6b641ebbb005b8f6e052b7cf419f6af66e099d5ba29843742ac23193cc', '[\"*\"]', NULL, NULL, '2024-11-21 16:07:05', '2024-11-21 16:07:05'),
(3, 'App\\Models\\User', 22, 'auth_token', '04523d867ca463bf8a69274bb2da533e181fe0ad0095a2ce91c35b269730a5ce', '[\"*\"]', NULL, NULL, '2024-11-21 16:06:51', '2024-11-21 16:06:51'),
(5, 'App\\Models\\User', 22, 'auth_token', '19087535fc8cbbb04eca646e787c693b565960a70f86ac60558f82b21123e3bc', '[\"*\"]', NULL, NULL, '2024-11-21 16:07:43', '2024-11-21 16:07:43'),
(6, 'App\\Models\\User', 22, 'auth_token', '347a0881a266895d5243dbbc88bbb63cb22e2ba2c8640f0524d060432b3b14a8', '[\"*\"]', '2024-11-21 16:08:16', NULL, '2024-11-21 16:07:56', '2024-11-21 16:08:16'),
(7, 'App\\Models\\User', 1, 'auth_token', 'c12cabdc25b1590994aea5b11cfb1a5e8d21c6ff7fea388ac2eee74a06b840e0', '[\"*\"]', '2024-11-21 16:11:29', NULL, '2024-11-21 16:11:02', '2024-11-21 16:11:29');
